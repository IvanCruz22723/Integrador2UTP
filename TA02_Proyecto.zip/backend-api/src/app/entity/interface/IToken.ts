
interface IToken {
    id: string,
    iat: number,
    exp: number
}
export = IToken